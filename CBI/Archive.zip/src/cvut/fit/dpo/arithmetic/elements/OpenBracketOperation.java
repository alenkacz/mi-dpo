package cvut.fit.dpo.arithmetic.elements;


public class OpenBracketOperation implements ExpressionElement
{

	@Override
	public String stringValue()
	{
		return "(";
	}

}
