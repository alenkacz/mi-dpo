package cvut.fit.dpo.arithmetic.elements;


public class CloseBracketOperation implements ExpressionElement
{

	@Override
	public String stringValue()
	{
		return ")";
	}

}
