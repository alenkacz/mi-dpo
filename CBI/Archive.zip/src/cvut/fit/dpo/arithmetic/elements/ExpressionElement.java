package cvut.fit.dpo.arithmetic.elements;

public interface ExpressionElement
{
	public String stringValue();
}
